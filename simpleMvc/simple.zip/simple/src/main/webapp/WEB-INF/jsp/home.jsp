<html>
<div>
    <h1>Hi, From the Home Page</h1>
    <a href="">New page</a>
</div>
</html>